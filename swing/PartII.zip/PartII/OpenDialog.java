import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.*;

public class OpenDialog extends JDialog {
    public OpenDialog(JFrame owner) {
        super(owner, "About Dialog Test",true);
        JLabel l = new JLabel("<html><h1>Hello World</h1></html>");
        add(l, BorderLayout.CENTER);
        JPanel panel = new JPanel();
        JButton ok = new JButton("OK");
        ok.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                setVisible(false);
            }
        });
        panel.add(ok);
        add(panel, BorderLayout.SOUTH);
        // setSize(250, 150);
    }
}
