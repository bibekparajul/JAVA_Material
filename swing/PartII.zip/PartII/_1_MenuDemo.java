import javax.swing.*;
import java.awt.event.*;

class _1_MenuDemo{
    _1_MenuDemo(){
        JFrame f = new JFrame("Simple Menu Demo");
        JMenuBar mb = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenu editMenu = new JMenu("Edit");
        JMenu helpMenu = new JMenu("Help");

        mb.add(fileMenu);
        mb.add(editMenu);
        mb.add(helpMenu);

        AbstractAction exitAction = new AbstractAction("Exit") {
            public void actionPerformed(ActionEvent e){
                System.exit(0);
            }
        };
        
        JMenuItem exitMenuItem = new JMenuItem(exitAction);
        exitMenuItem.setAccelerator(KeyStroke.getKeyStroke("ctrl E"));
        // exitMenuItem.addActionListener(exitAction);
        // exitMenuItem.setAction(exitAction);
        fileMenu.add(exitMenuItem);

        JMenuItem cutMenuItem = new JMenuItem("Cut",new ImageIcon("cut.png"));
        JMenuItem copyMenuItem = new JMenuItem("Copy");
        JMenuItem pasteMenuItem = new JMenuItem("Paste");

        JMenu optionsMenu = new JMenu("Options");

        JCheckBoxMenuItem readOnly = new JCheckBoxMenuItem("Read-only");
        readOnly.setSelected(true);
        JRadioButtonMenuItem insert = new JRadioButtonMenuItem("Insert");
        insert.setSelected(true);
        JRadioButtonMenuItem overtype = new JRadioButtonMenuItem("Overtype");

        optionsMenu.add(readOnly);
        optionsMenu.add(insert);
        optionsMenu.add(overtype);

        editMenu.add(cutMenuItem);
        editMenu.add(copyMenuItem);
        editMenu.add(pasteMenuItem);
        editMenu.addSeparator();
        editMenu.add(optionsMenu);

        f.setJMenuBar(mb);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setSize(400,400);
        f.setVisible(true);
    }
    public static void main(String[] args) {
        new _1_MenuDemo();
    }
}