import java.awt.event.ActionListener;

import javax.swing.*;
import java.awt.event.*;

public class _2_PopupDemo {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Popup Menu Example");
        JButton button = new JButton("Show Popup Menu");

        // Create a popup menu
        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem menuItem1 = new JMenuItem("Menu Item 1");
        JMenuItem menuItem2 = new JMenuItem("Menu Item 2");
        JMenuItem menuItem3 = new JMenuItem("Menu Item 3");

        // Add menu items to the popup menu
        popupMenu.add(menuItem1);
        popupMenu.add(menuItem2);
        popupMenu.add(menuItem3);

        // Set the button's action to show the popup menu
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                popupMenu.show(button,0,0);
            }
        });

        frame.add(button);

        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
