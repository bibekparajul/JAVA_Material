import javax.swing.*;
import java.awt.event.*;

public class MenuDemo {
    public static void main(String[] args) {
        JFrame f = new JFrame("Menu Demo");

        JMenuBar mb = new JMenuBar();

        JMenu file = new JMenu("File");
        JMenu edit = new JMenu("Edit");
        JMenu help = new JMenu("Help");

        mb.add(file);
        mb.add(edit);
        mb.add(help);

        JMenuItem open = new JMenuItem("Open");
        JMenuItem save = new JMenuItem("Save");
        JMenuItem exit = new JMenuItem("Exit");

        JMenuItem cut = new JMenuItem("Cut");
        JMenuItem copy = new JMenuItem("Copy");
        JMenuItem paste = new JMenuItem("Paste");

        edit.add(cut);
        edit.add(copy);
        edit.add(paste);

        JMenu options = new JMenu("Options");
        edit.add(options);

        JCheckBoxMenuItem readonly = new JCheckBoxMenuItem("Read-only");
        readonly.setSelected(true);
        JRadioButtonMenuItem overtype = new JRadioButtonMenuItem("overtype");

        options.add(readonly);
        options.add(overtype);



        exit.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                System.exit(0);
            }
        });

        file.add(open);
        file.add(save);
        file.add(exit);

        f.setJMenuBar(mb);

        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setSize(300,300);
        f.setVisible(true);
    }
}
