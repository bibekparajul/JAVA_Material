import java.io.File;

import javax.swing.*;
import java.awt.event.*;

public class _10_FileChooser extends JFrame{
    _10_FileChooser(){
        super("JFileChooser Example");

        // Create a button to trigger the file chooser
        JButton openButton = new JButton("Open File Chooser");
        openButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();

                // Show the file chooser dialog
                int result = fileChooser.showOpenDialog(_10_FileChooser.this);

                // Check if a file was selected
                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    JOptionPane.showMessageDialog(_10_FileChooser.this, "Selected file: " + selectedFile.getAbsolutePath());
                } else {
                    JOptionPane.showMessageDialog(_10_FileChooser.this, "File selection canceled.");
                }
            }
        });

        // Add the button to the main frame
        add(openButton);

        // Set up the main frame
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    public static void main(String[] args) {
        new _10_FileChooser();
    }
}
