import java.awt.event.ActionListener;

import javax.swing.*;
import java.awt.event.*;

public class _5_CustomDialog extends JFrame{
    public OpenDialog openDialog;
    _5_CustomDialog(){

        JMenuBar mb = new JMenuBar();
        setJMenuBar(mb);

        JMenu fileMenu = new JMenu("File");
        mb.add(fileMenu);

        JMenuItem openMenuItem = new JMenuItem("Open");
        fileMenu.add(openMenuItem);

        openMenuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                if(openDialog == null){
                    openDialog = new OpenDialog(_5_CustomDialog.this);
                }
                openDialog.setSize(300,300);
                openDialog.setVisible(true);
            }
        });

        setSize(300,200);
        setVisible(true);
    }
    public static void main(String[] args) {
        new _5_CustomDialog();
    }
}
