import javax.swing.*;
import java.awt.event.*;
import java.awt.BorderLayout;
import java.awt.Color;

class _6_ColorChooserDemo extends JFrame{
    Color color = Color.BLACK;
    _6_ColorChooserDemo(){

        JPanel p = new JPanel();
        p.setBackground(color);
        JButton b = new JButton("Choose color");

        b.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e){
                color = JColorChooser.showDialog(_6_ColorChooserDemo.this, "Choose a color", color);
                if(color == null){
                    color = Color.BLACK;
                }
                p.setBackground(color);
           } 
        });

        add(p,BorderLayout.CENTER);
        add(b,BorderLayout.SOUTH);

        setSize(400,400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    public static void main(String[] args) {
        new _6_ColorChooserDemo();
    }
}