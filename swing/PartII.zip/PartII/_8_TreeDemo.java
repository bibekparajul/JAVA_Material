import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;

public class _8_TreeDemo extends JFrame{
    _8_TreeDemo(){
        super("Tree Demo");

        // Create the root node
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("Root");

        // Create some child nodes
        DefaultMutableTreeNode node1 = new DefaultMutableTreeNode("Node 1");
        DefaultMutableTreeNode node2 = new DefaultMutableTreeNode("Node 2");
        DefaultMutableTreeNode node3 = new DefaultMutableTreeNode("Node 3");

        // Add child nodes to the root
        root.add(node1);
        root.add(node2);
        root.add(node3);


        // Create the tree with the root node
        JTree tree = new JTree(root);

        // Create a scroll pane and add the tree to it
        JScrollPane scrollPane = new JScrollPane(tree);

        // Add the scroll pane to the main frame
        add(scrollPane);

        // Set up the main frame
        setSize(300, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
    public static void main(String[] args) {
        new _8_TreeDemo();
    }
}
