import javax.swing.*;
// import java.awt.event.*;
import java.awt.*;

public class _7_MDIDemo extends JFrame{
    _7_MDIDemo(){
        super("MDI Demo");

        JDesktopPane dp = new JDesktopPane();
        add(dp);

        // Internal Frame
        JInternalFrame internalFrame1 = new JInternalFrame("Frame 1", true, true, true, true);
        internalFrame1.setSize(200,100);
        internalFrame1.setLocation(50,50);
        JLabel l = new JLabel("This is a content");
        JButton b = new JButton("Close");
        internalFrame1.add(l,BorderLayout.CENTER);
        internalFrame1.add(b,BorderLayout.SOUTH);
        dp.add(internalFrame1);
        internalFrame1.setVisible(true);

        JInternalFrame internalFrame2 = new JInternalFrame("Frame 2", true, true, true, true);
        internalFrame2.setSize(200,100);
        internalFrame2.setLocation(300,50);
        JLabel l2 = new JLabel("This is a content");
        JButton b2 = new JButton("Close");
        internalFrame2.add(l2,BorderLayout.CENTER);
        internalFrame2.add(b2,BorderLayout.SOUTH);
        dp.add(internalFrame2);
        internalFrame2.setVisible(true);


        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600,400);
        setVisible(true);
    }
    public static void main(String[] args) {
        new _7_MDIDemo();
    }
}
