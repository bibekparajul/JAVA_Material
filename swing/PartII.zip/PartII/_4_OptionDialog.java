import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class _4_OptionDialog {
    public static void main(String[] args) {

        Object[] options = {"Option 1", "Option 2", "Option 3"};

        JFrame f = new JFrame("Option Dialog Example");

        JButton b = new JButton("Click me");
        b.setBounds(40,30,200,200);

        f.add(b);

        b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // JOptionPane.showMessageDialog(f, "Message", "Title",JOptionPane.QUESTION_MESSAGE);
                // JOptionPane.showConfirmDialog(f, "Message", "Title",JOptionPane.WARNING_MESSAGE);
                // int result = JOptionPane.showOptionDialog(f,"Message","Title",JOptionPane.YES_OPTION,JOptionPane.WARNING_MESSAGE,null,options,options[0]);
                // if (result >= 0) {
                //     JOptionPane.showMessageDialog(f, "You chose "+ options[result]);
                // } else  {
                //     JOptionPane.showMessageDialog(f, "You chose cancel option");
                // }
                String userInput = JOptionPane.showInputDialog(f,"Enter your name:");
                if (userInput != null) {
                    JOptionPane.showMessageDialog(f, "Hello, " + userInput + "!");
                } else {
                    JOptionPane.showMessageDialog(f, "You cancelled or closed the dialog.");
                }


            }   
        });

        f.setLayout(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setSize(400,400);
        f.setVisible(true);
    }
}
