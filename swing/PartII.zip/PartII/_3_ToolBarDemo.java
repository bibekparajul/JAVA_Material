import javax.swing.*;
import java.awt.event.*;

public class _3_ToolBarDemo {
    public static void main(String[] args) {
        JFrame frame = new JFrame("JToolBar Example");

        // Create a toolbar
        JToolBar toolBar = new JToolBar("My Toolbar",SwingConstants.VERTICAL);

        // Create toolbar buttons
        JButton openButton = new JButton("Open");
        JButton saveButton = new JButton("Save");
        JButton cutButton = new JButton("Cut");
        JButton copyButton = new JButton("Copy");
        JButton pasteButton = new JButton("Paste");

        // Add action listeners to the buttons
        openButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Open action performed");
            }
        });

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Save action performed");
            }
        });

        cutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Cut action performed");
            }
        });

        copyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Copy action performed");
            }
        });

        pasteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Paste action performed");
            }
        });

        // Add buttons to the toolbar
        toolBar.add(openButton);
        toolBar.add(saveButton);
        toolBar.addSeparator(); // Add a separator between groups of buttons
        toolBar.add(cutButton);
        toolBar.add(copyButton);
        toolBar.add(pasteButton);

        // Add the toolbar to the frame
        frame.add(toolBar);

        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
